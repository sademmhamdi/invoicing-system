<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Email Configuration
| -------------------------------------------------------------------------
| This file contains the email configuration for the application.
| You can modify these settings based on your email provider.
*/

$config['protocol'] = 'smtp'; // Use 'smtp' for SMTP, 'mail' for PHP mail() function
$config['smtp_host'] = 'localhost'; // Your SMTP host
$config['smtp_port'] = 465; // SMTP port (587 for TLS, 465 for SSL)
$config['smtp_user'] = 'noreply@invoicing.amaziverse.io'; // Your SMTP username
$config['smtp_pass'] = 'KDBI*&^%*873w87t3rbe9873hg876'; // Your SMTP password
$config['smtp_crypto'] = 'ssl'; // 'tls' or 'ssl'
$config['mailtype'] = 'html'; // 'html' or 'text'
$config['charset'] = 'utf-8';
$config['wordwrap'] = TRUE;
$config['newline'] = "\r\n";

// For Gmail SMTP (if you want to use Gmail)
/*
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.gmail.com';
$config['smtp_port'] = 587;
$config['smtp_user'] = 'your-email@gmail.com';
$config['smtp_pass'] = 'your-app-password';
$config['smtp_crypto'] = 'tls';
*/
