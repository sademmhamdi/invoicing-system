<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('form_validation', 'email'));
        $this->load->config('email');
    }

    public function index()
    {
        // Load the contact form view
        $this->load->view('header');
        $this->load->view('contact_form');
        $this->load->view('footer');
    }

    public function request_quote()
    {
        // Load the request quote form view
        $this->load->view('header');
        $this->load->view('request_quote');
        $this->load->view('footer');
    }

    public function submit_contact()
    {
        // Set form validation rules
        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
        $this->form_validation->set_rules('phone', 'Phone', 'trim');
        $this->form_validation->set_rules('comments', 'Message', 'required|trim');

        if ($this->form_validation->run() == FALSE) {
            // Validation failed, reload form with errors
            $this->load->view('header');
            $this->load->view('contact_form');
            $this->load->view('footer');
        } else {
            // Validation passed, process the form
            $this->_send_contact_email();
        }
    }

    public function submit_quote()
    {
        // Set form validation rules for quote request
        $this->form_validation->set_rules('full_name', 'Full Name', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
        $this->form_validation->set_rules('contact_number', 'Contact Number', 'required|trim');
        $this->form_validation->set_rules('company_size', 'Company Size', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required|trim');

        if ($this->form_validation->run() == FALSE) {
            // Validation failed, reload form with errors
            $this->load->view('header');
            $this->load->view('request_quote');
            $this->load->view('footer');
        } else {
            // Validation passed, process the quote request
            $this->_send_quote_email();
        }
    }

    private function _send_contact_email()
    {
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');
        $message = $this->input->post('comments');

        // Initialize email library with configuration
        $this->email->initialize($this->config->item('email'));
        
        // Configure email
        $this->email->from('noreply@' . $_SERVER['HTTP_HOST'], 'Invoice Landing Page');
        $this->email->to('support@amaziverse.io'); // Change this to your email
        $this->email->subject('New Contact Form Submission');
        
        $email_body = "<h3>New contact form submission:</h3>";
        $email_body .= "<p><strong>Name:</strong> " . htmlspecialchars($name) . "</p>";
        $email_body .= "<p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>";
        $email_body .= "<p><strong>Phone:</strong> " . htmlspecialchars($phone) . "</p>";
        $email_body .= "<p><strong>Message:</strong><br>" . nl2br(htmlspecialchars($message)) . "</p>";
        $email_body .= "<p><strong>Submitted on:</strong> " . date('Y-m-d H:i:s') . "</p>";
        
        $this->email->message($email_body);

        if ($this->email->send()) {
            $data['success'] = true;
            $data['message'] = 'Thank you for contacting us! We will reply within maximum 48 hours.';
        } else {
            $data['success'] = false;
            $data['message'] = 'Sorry, there was an error sending your message. Please try again.';
            // For debugging: log_message('error', $this->email->print_debugger());
        }

        $this->load->view('header');
        $this->load->view('contact_thank_you', $data);
        $this->load->view('footer');
    }

    private function _send_quote_email()
    {
        $full_name = $this->input->post('full_name');
        $email = $this->input->post('email');
        $contact_number = $this->input->post('contact_number');
        $company_size = $this->input->post('company_size');
        $description = $this->input->post('description');

        // Initialize email library with configuration
        $this->email->initialize($this->config->item('email'));
        
        // Configure email
        $this->email->from('noreply@' . $_SERVER['HTTP_HOST'], 'Invoice Landing Page');
        $this->email->to('support@amaziverse.io'); // Change this to your email
        $this->email->subject('New Quote Request');
        
        $email_body = "<h3>New quote request submission:</h3>";
        $email_body .= "<p><strong>Full Name:</strong> " . htmlspecialchars($full_name) . "</p>";
        $email_body .= "<p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>";
        $email_body .= "<p><strong>Contact Number:</strong> " . htmlspecialchars($contact_number) . "</p>";
        $email_body .= "<p><strong>Company Size:</strong> " . htmlspecialchars($company_size) . "</p>";
        $email_body .= "<p><strong>Description:</strong><br>" . nl2br(htmlspecialchars($description)) . "</p>";
        $email_body .= "<p><strong>Submitted on:</strong> " . date('Y-m-d H:i:s') . "</p>";
        
        $this->email->message($email_body);

        if ($this->email->send()) {
            $data['success'] = true;
            $data['message'] = 'Thank you for requesting a quote! We will reply within maximum 48 hours with a detailed proposal.';
        } else {
            $data['success'] = false;
            $data['message'] = 'Sorry, there was an error sending your quote request. Please try again.';
            // For debugging: log_message('error', $this->email->print_debugger());
        }

        $this->load->view('header');
        $this->load->view('quote_thank_you', $data);
        $this->load->view('footer');
    }
}
