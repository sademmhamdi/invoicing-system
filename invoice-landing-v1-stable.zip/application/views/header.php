<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Primary SEO -->
    <meta name="description" content="UAE invoicing & billing software — FTA/EmaraTax‑compliant, bilingual (Arabic/English), VAT 5% ready. Create invoices, automate payment reminders, manage recurring billing & calendar, run VAT reports, and accept online payments via Stripe, PayTabs, Telr. Built for SMBs and enterprises across the UAE.">
    <meta name="robots" content="index,follow,max-snippet:-1,max-image-preview:large,max-video-preview:-1">

    <!-- ========== Page Title ========== -->
    <title>UAE Invoicing & Billing Software | FTA/EmaraTax Compliant | Arabic‑English</title>

    <!-- Canonical & Hreflang (edit URLs to your live routes) -->
    <link rel="canonical" href="<?= base_url() ?>">
    <link rel="alternate" href="<?= base_url() ?>" hreflang="en">
    <link rel="alternate" href="<?= base_url('ar/') ?>" hreflang="ar">
    <link rel="alternate" href="<?= base_url() ?>" hreflang="x-default">

    <!-- Open Graph -->
    <meta property="og:title" content="UAE Invoicing & Billing Software | FTA/EmaraTax Compliant | Arabic‑English">
    <meta property="og:description" content="Bilingual UAE invoicing system with VAT 5% compliance, automated reminders, recurring billing, VAT reports & local payment gateways.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= base_url() ?>">
    <meta property="og:image" content="<?= base_url('assets/img/og-cover.jpg') ?>">
    <meta property="og:locale" content="en_AE">

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="UAE Invoicing & Billing Software | FTA/EmaraTax Compliant">
    <meta name="twitter:description" content="Arabic/English invoicing, VAT 5%, EmaraTax ready, automated reminders, recurring billing & VAT reports.">
    <meta name="twitter:image" content="<?= base_url('assets/img/og-cover.jpg') ?>">

    <!-- Favicons -->
    <link rel="shortcut icon" href="assets/img/icon.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="<?= base_url('assets/img/apple-touch-icon.png') ?>">

    <!-- ========== Start Stylesheet ========== -->
    <link href="<?= base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/font-awesome.min.css') ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/elegant-icons.css') ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/flaticon-set.css') ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/magnific-popup.css') ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/owl.carousel.min.css') ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/owl.theme.default.min.css') ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/animate.css') ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/helper.css') ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/validnavs.css') ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/style.css') ?>" rel="stylesheet" />
    <link href="<?= base_url('assets/css/responsive.css') ?>" rel="stylesheet" />
    <!-- ========== End Stylesheet ========== -->

    <!-- JSON-LD: Organization -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "Amaziverse Invoicing",
      "url": "<?= base_url() ?>",
      "logo": "<?= base_url('assets/img/logo1.png') ?>",
      "sameAs": [
        "https://www.facebook.com/yourbrand",
        "https://www.linkedin.com/company/yourbrand",
        "https://x.com/yourbrand"
      ]
    }
    </script>

    <!-- JSON-LD: Product + SoftwareApplication -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [{
        "@type": "Product",
        "name": "UAE Invoicing & Billing Software",
        "image": "<?= base_url('assets/img/og-cover.jpg') ?>",
        "description": "FTA/EmaraTax compliant invoicing software for the UAE with Arabic/English invoices, VAT 5%, automated payment reminders, recurring billing, VAT reports, and local payment gateways.",
        "brand": {"@type": "Brand", "name": "Amaziverse"},
        "sku": "INV-UAE-SaaS",
        "offers": {
          "@type": "Offer",
          "price": "0",
          "priceCurrency": "AED",
          "url": "<?= base_url('#pricing') ?>",
          "availability": "https://schema.org/InStock"
        },
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "4.8",
          "reviewCount": "112"
        }
      },
      {
        "@type": "SoftwareApplication",
        "name": "Amaziverse Invoicing (UAE)",
        "operatingSystem": "Web, iOS, Android",
        "applicationCategory": "BusinessApplication",
        "offers": {
          "@type": "Offer",
          "price": "0",
          "priceCurrency": "AED"
        }
      }]
    }
    </script>

    <!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->
</head>

<body>
    <!-- Start Preloader 
    ============================================= -->
    <div id="preloader">
        <div id="softing-preloader" class="softing-preloader">
            <div class="animation-preloader">
                <div class="spinner"></div>
                <div class="txt-loading">
                    <span data-text-preloader="I" class="letters-loading">I</span>
                    <span data-text-preloader="N" class="letters-loading">N</span>
                    <span data-text-preloader="V" class="letters-loading">V</span>
                    <span data-text-preloader="O" class="letters-loading">O</span>
                    <span data-text-preloader="I" class="letters-loading">I</span>
                    <span data-text-preloader="C" class="letters-loading">C</span>
                    <span data-text-preloader="I" class="letters-loading">I</span>
                    <span data-text-preloader="N" class="letters-loading">N</span>
                    <span data-text-preloader="G" class="letters-loading">G</span>
                </div>
            </div>
            <div class="loader">
                <div class="row">
                    <div class="col-3 loader-section section-left"><div class="bg"></div></div>
                    <div class="col-3 loader-section section-left"><div class="bg"></div></div>
                    <div class="col-3 loader-section section-right"><div class="bg"></div></div>
                    <div class="col-3 loader-section section-right"><div class="bg"></div></div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Preloader -->

    <!-- Header 
    ============================================= -->
    <header id="home">
        <!-- Start Navigation -->
        <nav class="navbar mobile-sidenav navbar-sticky navbar-default validnavs navbar-fixed dark no-background">
            <div class="container d-flex justify-content-between align-items-center">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars" aria-hidden="true"></i><span class="sr-only">Toggle navigation</span>
                    </button>
                    <a class="navbar-brand" href="index.html" aria-label="Amaziverse Invoicing Home">
                        <img src="assets/img/logo1.png" class="logo" alt="UAE invoicing software logo (FTA/EmaraTax compliant)">
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <img src="assets/img/logo1.png" alt="Amaziverse Invoicing brand mark">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-times" aria-hidden="true"></i><span class="sr-only">Close navigation</span>
                    </button>
                    <ul class="nav navbar-nav navbar-center" data-in="fadeInDown" data-out="fadeOutUp">
                        <li><a class="smooth-menu" href="#home">Home</a></li>
                        <li><a class="smooth-menu" href="#features">Features</a></li>
                        <li><a class="smooth-menu" href="#overview">Overview</a></li>
                        <li><a class="smooth-menu" href="#pricing">Pricing</a></li>
                        <li><a class="smooth-menu" href="#blog">Blog</a></li>
                        <li><a class="smooth-menu" href="#contact">Contact</a></li>
                    </ul>
                </div><!-- /.navbar-collapse -->

                <div class="attr-right">
                    <!-- Start Attribute Navigation -->
                    <div class="attr-nav">
                        <ul>
                            <li class="button">
                                <a href="#pricing" aria-label="Start free trial">Start Free Trial</a>
                            </li>
                        </ul>
                    </div>
                    <!-- End Attribute Navigation -->
                </div>
                <!-- Main Nav -->
            </div>
            <!-- Overlay screen for menu -->
            <div class="overlay-screen"></div>
            <!-- End Overlay screen for menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Header -->
